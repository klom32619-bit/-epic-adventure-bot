import os
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, ContextTypes

# توکن را در متغیر محیطی BOT_TOKEN قرار دهید؛ آن را داخل این فایل ننویسید.
BOT_TOKEN = os.getenv("BOT_TOKEN")
GAME_URL = "https://zingy-clafoutis-f61bf1.netlify.app"

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logging.getLogger("httpx").setLevel(logging.WARNING)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    keyboard = [[InlineKeyboardButton("🎮 شروع بازی", url=GAME_URL)]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    message = (
        "🌟 به Epic Adventure خوش اومدی!\n\n"
        "آماده‌ای وارد ماجراجویی بشی؟\n"
        "روی دکمه زیر بزن و بازی رو شروع کن."
    )
    if update.effective_message:
        await update.effective_message.reply_text(
            message,
            reply_markup=reply_markup,
        )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.effective_message:
        await update.effective_message.reply_text(
            "برای شروع ماجراجویی، /start رو بزن."
        )

def main() -> None:
    if not BOT_TOKEN:
        raise RuntimeError(
            "متغیر امن BOT_TOKEN تنظیم نشده است. راهنما را در README_FA.md ببینید."
        )
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    print("Epic Adventure bot is running. Stop with Ctrl+C.")
    app.run_polling()

if __name__ == "__main__":
    main()
